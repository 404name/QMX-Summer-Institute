import {createRouter, createWebHistory} from 'vue-router'
import Login from "../views/Login";
import Layout from "../layout/Layout";
import home from "../views/Home"
import register from "../views/Register"
import Message from "../views/Message";
import HomePage from "../views/HomePage";
import Look from "../views/Look";
import Myself from "../views/Myself";
import Book from "../views/Book";



const routes = [
    {
        path: '/look',
        name: 'Look',
        component: Look
    },
    {
        path: '/',
        name: 'Login',
        component: Login
    },
    {
        path: '/register',
        name: 'register',
        component: register
    },

    {
        path: '/home',
        name: 'Layout',
        component: Layout,
        redirect: "/home/homepage",
        children: [
            {
                path: 'user',
                name: 'home',
                component: home,
            },
            {
                path: 'homepage',
                name: 'homepage',
                component: HomePage
            },
            {
                path: 'message',
                name: 'message',
                component: Message
            },
            {
                path: 'book',
                name: 'book',
                component: Book
            },
            {
                path: 'myself',
                name: 'myself',
                component: Myself
            }
        ],
    },
]

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes
})

router.beforeEach((to) => {
    if (to.path === '/home/user') {
        let userStr = sessionStorage.getItem("user") || "{}"
        let data = JSON.parse(userStr);
        if (data.role === 1) {
            console.log("1")
        } else {
            console.log("2")
            router.push('/home/homepage')
        }
    }
})


export default router
