<template>
    <div class="Header">
        <div class="HLeft">后台管理</div>
        <div class="HMiddle"></div>
        <div class="HRight">
            <el-dropdown style="cursor: pointer" trigger="click">
                <span class="el-dropdown-link">
                    {{nickName}}<i class="el-icon-arrow-down el-icon--right"></i>
                </span>
                <template #dropdown>
                    <el-dropdown-menu>
                        <el-dropdown-item @click="exit">退出登录
                        </el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>
        </div>
    </div>
</template>

<script>

    export default {
        name: "Header",
        data() {
            return {
                nickName: ""
            }
        },
        created() {
            let str = sessionStorage.getItem("user") || "{}"
            this.nickName = JSON.parse(str).nickName
            if(this.nickName === "") {
                this.nickName = "干饭人"
            }
        },
        methods: {
            exit() {
                sessionStorage.removeItem("user")
                this.$router.push("/")
            },
        }
    };
</script>

<style scoped>
    .Header {
        height: 50px;
        line-height: 50px;
        border-bottom: 1px solid #eee;
        display: flex;
    }

    .HLeft {
        width: 200px;
        padding-left: 30px;
        font-weight: bold;
        color: #409eff;
    }

    .HMiddle {
        flex: 1;
    }

    .HRight {
        width: 100px;
    }

</style>