<template>
    <div>
        <el-menu
                style="width: 200px; min-height: calc(100vh - 50px)"
                :default-active="path"
                :default-openeds="[1]"
                router
                class="el-menu-vertical-demo">
            <el-menu-item index="/home/homepage" :route="{path: '/home/homepage'} ">首页</el-menu-item>
            <el-submenu index="1">
                <template #title>数据管理</template>
                <el-menu-item index="/home/user" v-if="user.role === 1" :route="{path: '/home/user'}">用户管理</el-menu-item>
                <el-menu-item index="/home/message" :route="{path: '/home/message'} ">个人信息</el-menu-item>
            </el-submenu>
            <el-submenu index="2">
                <template #title>图书模块</template>
                <el-menu-item index="/home/book"    :route="{path: '/home/book'}">图书大厅</el-menu-item>
                <el-menu-item index="/home/myself" v-if="user.role === 2" :route="{path: '/home/myself'} ">我的图书</el-menu-item>
            </el-submenu>
        </el-menu>
    </div>
</template>

<script>
    import request from "../utils/request";
    export default {
        name: "Aside",
        data() {
            return {
                user: {},
                path: this.$route.path
            }
        },
        created() {
            let userStr = sessionStorage.getItem("user") || "{}"
            this.user = JSON.parse(userStr)
            //请求服务端，确认当前登录用户的 合法信息
            request.get("/api/user/" + this.user.id).then(res => {
                if (res.code === '0') {
                    this.user = res.data
                }
            })
        }
    }
</script>

<style scoped>

</style>