<template>
    <div class="block">
        <div class="hua">
            <div class="demonstration">滑动解锁</div>
            <el-slider v-model="value1" @input="hhh"></el-slider>
            <el-progress type="dashboard" :percentage="value1" :color="colors" class="f_hua">
                <span class="percentage-value f_font">{{ value1 }}%</span>
            </el-progress>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Look",
        data() {
            return {
                value1: 0,
                colors: [
                    {color: '#f56c6c', percentage: 20},
                    {color: '#e6a23c', percentage: 40},
                    {color: '#5cb87a', percentage: 60},
                    {color: '#1989fa', percentage: 80},
                    {color: '#6f7ad3', percentage: 100}
                ]
            }
        },
        methods: {
            hhh() {
                if (this.value1 === 100) {
                    this.$router.push("/")
                }
            }
        }
    }
</script>

<style scoped>
    .block {
        width: 100%;
        height: 100%;
        background: url("https://cdn.jsdelivr.net/gh/lysijj/image-host/imageAGG/1626824966831.jpeg");
        background-size: cover;
        overflow: hidden;
    }

    .hua {
        width: 50%;
        margin: 265px auto;
    }

    .demonstration {
        text-align: center;
        margin-bottom: 25px;
        font-size: 30px;
        font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
    }


    .f_hua {
        margin-top: 20px;
        text-align: center;
        position: absolute;
        left: 50%;
        transform: translate(-70px, 0px);
    }

    .f_font {
        color: black;
        font-size: 20px;
    }
</style>