<template>
    <div class="login_container">
        <div class="login_box">
            <div class="avatar_box">
                <!--头像-->
                <img src="https://cdn.jsdelivr.net/gh/lysijj/image-host/imageSJJG/c3d58ec5467b76e034ff80528621d85b_20180125085227_54954.jpg"/>
            </div>
            <!--添加表单-->
            <el-form
                    ref="loginFormRef"
                    :model="loginForm"
                    :rules="loginRules"
                    class="login_form"
                    label-width="0px"
                    size="normal"
            >
                <!--用户名-->
                <el-form-item prop="username">
                    <el-input
                            placeholder="请输入用户名"
                            v-model="loginForm.username"
                            prefix-icon="iconfont icon-denglu"
                    ></el-input>
                </el-form-item>
                <!--密码-->
                <el-form-item prop="password">
                    <el-input
                            placeholder="请输入密码"
                            v-model="loginForm.password"
                            prefix-icon="iconfont icon-mima"
                            show-password
                    ></el-input>
                </el-form-item>
                <!--按钮组-->
                <el-form-item class="button">
                    <el-button type="primary" @click="Login">登录</el-button>
                    <el-button type="info" @click="registers">注册</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
    import request from "../utils/request";

    export default {
        name: "Login",
        data() {
            return {
                loginForm: {
                    username: "",
                    password: "",
                },
                loginRules: {
                    username: [
                        {required: true, message: "请输入用户名", trigger: "blur"},
                        {min: 3, max: 8, message: "长度在 3 到 8 个字符", trigger: "blur"},
                    ],
                    password: [
                        {required: true, message: "请输入密码", trigger: "blur"},
                        {min: 3, max: 8, message: "密码为 3~8 位", trigger: "blur"},
                    ],
                },
            };
        },
        methods: {
            Login() {
                this.$refs['loginFormRef'].validate((valid) => {
                    if (valid) {
                        request.post("/api/user/login", this.loginForm).then(res => {
                            if (res.code === '0') {
                                this.$message({
                                    type: "success",
                                    message: "登录成功"
                                })
                                sessionStorage.setItem("user", JSON.stringify(res.data))
                                this.$router.push("/home")
                            } else {
                                this.$message({
                                    type: "error",
                                    message: "用户名或者密码错误"
                                })
                            }
                        })
                    } else {
                        this.$message({
                            type: "error",
                            message: "用户不合法"
                        })
                    }
                });
            },
            registers() {
                this.$router.push('/register')
            }
        },
    };
</script>

<style scoped>
    .login_container {
        background: url(https://cdn.jsdelivr.net/gh/lysijj/image-host/imagelunbo/b638c3be586a56d0c58419ceec459b60_1483416347978.jpg);
        background-size: cover;
        height: 100%;
    }

    .login_box {
        width: 450px;
        height: 300px;
        background-color: #fff;
        border-radius: 3px;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
    }

    .avatar_box {
        width: 130px;
        height: 130px;
        border: 1px solid #eee;
        border-radius: 50%;
        padding: 0px;
        box-shadow: 0 0 10px #898888;
        position: absolute;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    .avatar_box img {
        width: 100%;
        height: 100%;
        border-radius: 50%;
    }

    .button {
        display: flex;
        justify-content: flex-end;
        flex-direction: column;
        flex-wrap: wrap;
        align-content: flex-end;
    }

    .login_form {
        position: absolute;
        bottom: 0%;
        width: 100%;
        padding: 0 10px;
        box-sizing: border-box;
    }
</style>
