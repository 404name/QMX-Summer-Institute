<template>
    <div style="padding: 10px">
        <!--    搜索区域-->
        <div style="margin: 10px 0">
            <el-input v-model="search" placeholder="请输入关键字" style="width: 20%" clearable
                      prefix-icon="el-icon-search"></el-input>
            <el-button type="success" style="margin-left: 10px" @click="load">查询</el-button>
        </div>
        <el-table
                v-loading="loading"
                :data="tableData"
                border
                stripe
                style="width: 100%">
            <el-table-column
                    prop="name"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="price"
                    label="单价">
            </el-table-column>
            <el-table-column
                    prop="author"
                    label="作者">
            </el-table-column>
            <el-table-column
                    prop="createTime"
                    label="出版时间">
            </el-table-column>
            <el-table-column label="操作">
                <template #default="scope">
                    <el-button size="mini" @click="DeleteBook(scope.row)" type="danger">删除图书</el-button>
                </template>
            </el-table-column>
        </el-table>

        <div style="margin: 10px 0">
            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="currentPage"
                    :page-sizes="[3, 6, 10]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total">
            </el-pagination>

            <el-dialog title="提示" v-model="dialogVisible" width="30%">
                <template #footer>
                    <span class="dialog-footer">
                        <el-button type="primary" @click="">确 定</el-button>
                        <el-button @click="dialogVisible = false">取 消</el-button>
                    </span>
                </template>
            </el-dialog>

        </div>
    </div>
</template>

<script>

    import request from "../utils/request";

    export default {
        name: 'MyBook',
        components: {},
        data() {
            return {
                user: {},
                loading: true,
                form: {},
                dialogVisible: false,
                search: '',
                currentPage: 1,
                pageSize: 10,
                total: 0,
                tableData: []
            }
        },
        created() {
            let userStr = sessionStorage.getItem("user") || "{}"
            this.user = JSON.parse(userStr)
            // 请求服务端，确认当前登录用户的 合法信息
            request.get("/api/user/" + this.user.id).then(res => {
                if (res.code === '0') {
                    this.user = res.data
                }
            })

            this.load()
        },
        methods: {
            load() {
                this.loading = true
                request.get("/api/mybook/" + this.user.id, {
                    params: {
                        pageNum: this.currentPage,
                        pageSize: this.pageSize,
                        search: this.search
                    }
                }).then(res => {
                    this.loading = false
                    this.tableData = res.data.records
                    this.total = res.data.total
                })
            },
            DeleteBook(row) {
                console.log(row.id)
                request.delete("/api/mybook/" + row.id).then(res => {
                    if (res.code === '0') {
                        this.$message({
                            type: "success",
                            message: "删除成功"
                        })
                    } else {
                        this.$message({
                            type: "error",
                            message: "删除失败"
                        })
                    }
                    this.load()
                })

            },

            // handleEdit(row) {
            //     this.form = JSON.parse(JSON.stringify(row))
            //     this.dialogVisible = true
            // },
            // handleDelete(id) {
            //     request.delete("/api/book/" + id).then(res => {
            //         if (res.code === '0') {
            //             this.$message({
            //                 type: "success",
            //                 message: "删除成功"
            //             })
            //         } else {
            //             this.$message({
            //                 type: "error",
            //                 message: res.msg
            //             })
            //         }
            //         this.load()  // 删除之后重新加载表格的数据
            //     })
            // },
            handleSizeChange(pageSize) {   // 改变当前每页的个数触发
                this.pageSize = pageSize
                this.load()
            },
            handleCurrentChange(pageNum) {  // 改变当前页码触发
                this.currentPage = pageNum
                this.load()
            }
        }
    }
</script>
