<template>
    <div class="containerT">
        <n-result status="404" title="今天吃啥好嘞" description="干饭人干饭魂" size="huge">
            <template #footer>
                <n-gradient-text gradient="linear-gradient( #2af598 0%, #009efd 100%)">
                    老骥伏枥，志在千里，横扫饥饿，做回自己
                </n-gradient-text>
            </template>
        </n-result>
    </div>
</template>

<script>
    import {NResult} from 'naive-ui'
    import {NGradientText} from 'naive-ui'
    import {NCarousel} from 'naive-ui'

    export default {
        components: {
            NResult,
            NGradientText,
            NCarousel
        }
    }
</script>

<style scoped>
    .containerT {
        position: absolute;
        top: 15%;
        left: 41%;
    }

</style>
