package com.example.demo.eneity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@TableName("mybook")
@Data
public class MyBook {
    @TableId(type = IdType.AUTO)
    private String id;
    private String name;
    private BigDecimal price;
    private String author;
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date createTime;
    private int userId;


//    public void equal(Book book, Integer id) {
//        this.id = book.getId();
//        this.name = book.getName();
//        this.price = book.getPrice();
//        this.author = book.getAuthor();
//        this.createTime = book.getCreateTime();
//        this.userId = id;
//    }
}
