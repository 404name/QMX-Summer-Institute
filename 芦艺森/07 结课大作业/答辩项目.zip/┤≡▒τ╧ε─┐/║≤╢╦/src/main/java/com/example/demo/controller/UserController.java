package com.example.demo.controller;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.Result;
import com.example.demo.eneity.User;
import com.example.demo.mapper.UserMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/user")
@Api(tags = "用户模块")
public class UserController {

  @Resource UserMapper userMapper;

  @PostMapping("/login")
  @ApiOperation(value = "登录")
  public Result<?> login(@RequestBody User user) {
    User res =
        userMapper.selectOne(
            Wrappers.<User>lambdaQuery()
                .eq(User::getUsername, user.getUsername())
                .eq(User::getPassword, user.getPassword()));
    if (res == null) {
      return Result.error("-1", "用户名或密码错误");
    }
    return Result.success(res);
  }

  @PostMapping("/register")
  @ApiOperation(value = "注册")
  public Result<?> register(@RequestBody User user) {
    User res =
        userMapper.selectOne(
            Wrappers.<User>lambdaQuery().eq(User::getUsername, user.getUsername()));
    if (res != null) {
      return Result.error("-1", "用户名重复");
    }
    if (user.getPassword() == null) {
      user.setPassword("123456");
    }
    if (user.getRole() == null) {
      user.setRole(2);
    }
    userMapper.insert(user);
    return Result.success();
  }

  @PutMapping
  @ApiOperation(value = "修改用户信息")
  public Result<?> update(@RequestBody User user) {
    userMapper.updateById(user);
    return Result.success();
  }

  @DeleteMapping("/{id}")
  @ApiOperation(value = "删除用户")
  public Result<?> update(@PathVariable Long id) {
    userMapper.deleteById(id);
    return Result.success();
  }

  @GetMapping("/{id}")
  @ApiOperation(value = "查询单个用户")
  public Result<?> getById(@PathVariable Long id) {
    return Result.success(userMapper.selectById(id));
  }

  @GetMapping
  @ApiOperation(value = "分页插件")
  public Result<?> findPage(
      @RequestParam(defaultValue = "1") Integer pageNum,
      @RequestParam(defaultValue = "10") Integer pageSize,
      @RequestParam(defaultValue = "") String search) {
    LambdaQueryWrapper<User> wrapper = Wrappers.<User>lambdaQuery();
    if (StrUtil.isNotBlank(search)) {
      wrapper.like(User::getUsername, search);
    }
    Page<User> userPage = userMapper.selectPage(new Page<>(pageNum, pageSize), wrapper);
    return Result.success(userPage);
  }

  @GetMapping("/nowUser")
  @ApiOperation(value = "获取当前用户")
  public Result<?> nowUser(HttpServletResponse response, HttpServletRequest request) {
    return Result.success(request.getSession().getAttribute("user"));
  }

  @GetMapping("/logout")
  @ApiOperation(value = "注销")
  public Result<?> logout(HttpServletResponse response, HttpServletRequest request) {
    request.getSession().setAttribute("user", null);
    return Result.success("退出成功");
  }
}
