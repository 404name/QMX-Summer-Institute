package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.eneity.MyBook;

public interface MyBookMapper extends BaseMapper<MyBook> {

}
