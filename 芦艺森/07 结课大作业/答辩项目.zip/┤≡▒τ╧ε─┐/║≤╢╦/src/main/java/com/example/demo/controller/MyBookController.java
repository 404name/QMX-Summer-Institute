package com.example.demo.controller;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.Result;
import com.example.demo.eneity.Book;
import com.example.demo.eneity.MyBook;
import com.example.demo.eneity.User;
import com.example.demo.mapper.BookMapper;
import com.example.demo.mapper.MyBookMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/mybook")
@Api(tags = "我的图书")
public class MyBookController {

  @Resource MyBookMapper MyBookMapper;

  @PostMapping("/{id}")
  @ApiOperation(value = "添加")
  public Result<?> save(@RequestBody MyBook myBook, @PathVariable Integer id) {
    myBook.setUserId(id);
    myBook.setId(myBook.getId()+'.'+id);
    MyBook res = MyBookMapper.selectById(myBook.getId());
    if(res != null) {
      return Result.error("-1", "添加重复");
    }
    MyBookMapper.insert(myBook);
    return Result.success();
  }
  @DeleteMapping("/{id}")
  @ApiOperation(value = "删除")
  public Result<?> update(@PathVariable String id) {
    MyBookMapper.deleteById(id);
    return Result.success();
  }

  @GetMapping("/{id}")
  @ApiOperation(value = "分页插件")
  public Result<?> findPage(
      @RequestParam(defaultValue = "1") Integer pageNum,
      @RequestParam(defaultValue = "10") Integer pageSize,
      @RequestParam(defaultValue = "") String search,
      @PathVariable Integer id) {
    LambdaQueryWrapper<MyBook> wrapper = Wrappers.<MyBook>lambdaQuery();
    wrapper.eq(MyBook::getUserId, id);
    if (StrUtil.isNotBlank(search)) {
      wrapper.like(MyBook::getName, search);
    }
    Page<MyBook> BookPage = MyBookMapper.selectPage(new Page<>(pageNum, pageSize), wrapper);
    return Result.success(BookPage);
  }
}
