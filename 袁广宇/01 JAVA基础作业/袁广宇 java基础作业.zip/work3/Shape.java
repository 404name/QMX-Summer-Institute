package com.qmx.work3;

public abstract class Shape {

    public abstract double getArea();

    public abstract double getPerimeter();

}
