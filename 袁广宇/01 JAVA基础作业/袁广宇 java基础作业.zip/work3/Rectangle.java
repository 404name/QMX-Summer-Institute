package com.qmx.work3;

public class Rectangle extends Shape{
    private double height;
    private double weight;
    private double area;
    private double perimeter;

    public Rectangle(int height, int weight){
        this.height = height;
        this.weight = weight;
    }
    public void setHeight(double height) {
        this.height = height;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
    @Override
    public double getArea(){
        area = height * weight;
        return area;
    }
    @Override
    public double getPerimeter(){
        return 2 * (height + weight);
    }
}
