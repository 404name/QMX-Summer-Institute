package com.qmx.work3;

import com.qmx.work2.Pi;

public class Circle extends Shape{
    private double area;
    private double r;

    public void setR(double r) {
        this.r = r;
    }
    public Circle(int r){
        this.r = r;
    }
    @Override
    public double getArea(){
        area = Pi.PI * r * r;
        return area;
    }
    @Override
    public double getPerimeter(){
        return 2 * Pi.PI * r;
    }
}
