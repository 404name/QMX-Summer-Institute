package com.qmx.work3;

public class main {
    public static void main(String[] args){
        Shape rec = new Rectangle(2, 3);
        Shape cir = new Circle(2);
        System.out.println(rec.getArea());
        System.out.println(rec.getPerimeter());
        System.out.println(cir.getPerimeter());
        System.out.println(cir.getArea());
    }

}
