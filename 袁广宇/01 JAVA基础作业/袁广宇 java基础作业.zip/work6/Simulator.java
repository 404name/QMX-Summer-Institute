package com.qmx.work6;

public class Simulator {
    public void playSound(Animal animal){
        animal.getAnimalName();
    }
}
