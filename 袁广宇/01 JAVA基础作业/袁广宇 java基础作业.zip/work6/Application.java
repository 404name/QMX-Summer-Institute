package com.qmx.work6;

public class Application {
    public static void main(String[] args) {
        Simulator simulator = new Simulator();
        simulator.playSound(new Dog("旺财"));
        simulator.playSound(new Cat("小喵"));
    }
}
