package com.qmx.work6;

public interface Animal {
    void cry();
    String getAnimalName();
}
