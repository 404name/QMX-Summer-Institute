package com.qmx.work6;

public class Dog implements Animal {
    String name;
    Dog(String name){
        this.name = name;
    }
    @Override
    public void cry() {
        System.out.println("汪！");
    }

    @Override
    public String getAnimalName() {
        System.out.println(name);
        return name;
    }
}
