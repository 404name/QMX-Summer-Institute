package com.qmx.work6;

public class Cat implements Animal {
    String name;
    Cat(String name){
        this.name = name;
    }
    @Override
    public void cry() {
        System.out.println("喵~");
    }

    @Override
    public String getAnimalName() {
        System.out.println(name);
        return name;
    }
}
