package com.qmx.work1;

public class Convention_Numbers {

    public int f(int a, int b){
        int temp = 0;
        while( b != 0 ) {
            temp = a % b;
            a = b;
            b = temp;
        }
        //System.out.println("最大公约数："+ a);
        return a;
    }
}
