package com.qmx.work1;

public class Common_Numbers extends Convention_Numbers{

    public int f(int a, int b){
        System.out.println("最小公倍数：" + (a*b)/super.f(a, b));
        return (a*b)/super.f(a, b);
    }
}
