package com.qmx.work4;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListTest {
    public static void main(String[] args) {
        ArrayList mList = new ArrayList();
        mList.add("cat");
        mList.add("pig");
        mList.add("bird");
        for (int i = 0; i < mList.size(); i++) {
            System.out.println(mList.get(i));
        }
        for (Object string : mList) {
            System.out.println(string);
        }
        Iterator<String> iterator = mList.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}