package com.qmx.work2;

public class Cylinder extends Circle {
    private double high;

    public Cylinder(double r, double high){
        super(r);
        this.high = high;
    }
    public void setHigh(double high) {
        this.high = high;
        getVolume();
    }

    public double getHigh() {
        return high;
    }
    public double getVolume(){
        return Pi.PI * r * r * high;
    }
}
