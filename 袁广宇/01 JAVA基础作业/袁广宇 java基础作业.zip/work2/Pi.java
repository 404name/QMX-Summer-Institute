package com.qmx.work2;

public final class Pi {
    public static final double PI = 3.1415926;
}
