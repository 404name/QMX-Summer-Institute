package com.qmx.work2;

public class Cone extends Circle{
    private double high;
    private double volume;

    public Cone(double r, double high){
        super(r);
        this.high = high;
    }
    public double getHigh() {
        return high;
    }

    public void setHigh(double high) {
        this.high = high;
        getVolume();
    }

    public double getVolume(){
        volume = Pi.PI * r * r * high/3;
        return volume;
    }
}
