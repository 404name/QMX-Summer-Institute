package com.qmx.work2;

public class Circle<r> {
    protected double r;

    public Circle(double r){
        this.r = r;
    }

    public double getArea() {
        return Pi.PI * r * r;
    }

    public void setR(double r) {
        this.r = r;
    }
}
