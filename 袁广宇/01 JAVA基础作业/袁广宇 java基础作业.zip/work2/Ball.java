package com.qmx.work2;

public class Ball extends Circle{
    private double volume;

    public Ball(double r){
        super(r);
    }
    public double getVolume(){
        return Pi.PI * r * r * r * 3/4;
    }
}
