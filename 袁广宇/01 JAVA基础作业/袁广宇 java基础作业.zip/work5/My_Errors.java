package com.qmx.work5;

public class My_Errors {
    public static int method(String str, int index) {
        int[] array = {1, 2, 3, 4, 5};
        try{
            //array[5] = 10;
            for( int i = 0; i <= index; i++ ) {
                System.out.println(str.charAt(i));
            }
        } catch (StringIndexOutOfBoundsException e) {
            return 1;
        } catch(ArrayIndexOutOfBoundsException e) {
            return 0;
        }
        return 3;
    }

    public static void main(String[] args) {
        System.out.println(method("abcdefg", 7));
    }
}

