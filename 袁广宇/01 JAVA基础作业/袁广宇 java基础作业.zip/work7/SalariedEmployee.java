package com.qmx.work7;

public class SalariedEmployee extends Employee {
    private double monthlySalary;

    public SalariedEmployee(String name, String number, MyDate birthday, double mon) {
        super(name, number, birthday);
        this.monthlySalary = mon;
    }

    @Override
    public double earnings() {
        return monthlySalary;
    }
    public String toString(){
        super.toString();
        System.out.println("工种为SalariedEmployee:");
        return "SalariedEmployee";
    }

}
