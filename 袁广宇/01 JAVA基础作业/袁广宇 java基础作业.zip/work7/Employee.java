package com.qmx.work7;

public abstract class Employee {
    private String name;
    private String number;
    private MyDate birthday ;

    public abstract double earnings();

    public Employee(String name, String number, MyDate birthday){
        this.name = name;
        this.number = number;
        this.birthday = birthday;
    }

    public String toString(){
        System.out.println("姓名是：" + name);
        System.out.println("工号是：" + number);
        System.out.println("出生日期为：" + birthday.toDateString());
        return null;
    }

    public int getMonth(){
        return this.birthday.getMonth();
    }

    public String getName(){
        return name;
    }
}
