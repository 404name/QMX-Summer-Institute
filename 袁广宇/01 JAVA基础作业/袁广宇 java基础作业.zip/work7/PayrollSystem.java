package com.qmx.work7;

import java.util.Scanner;

public class PayrollSystem {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("请输入月份");
        int month = input.nextInt();
        Employee[] employees = new Employee[2];
        employees[0] = new  HourlyEmployee("程序员","996",new MyDate(2000, 10, 24), 12,30);
        employees[1] = new  SalariedEmployee("教师","z9w5",new MyDate(2000, 9, 10), 5000);

        for (int i = 0; i < employees.length; i++) {
            +employees[i].toString();
            if( month == employees[i].getMonth()){
                System.out.println("本月是" + employees[i].getName() + "的生日" + "工资加100元");
            }
            System.out.println("工资为" + (month == employees[i].getMonth() ? employees[i].earnings()  + 100: employees[i].earnings()));
        }
    }
}
