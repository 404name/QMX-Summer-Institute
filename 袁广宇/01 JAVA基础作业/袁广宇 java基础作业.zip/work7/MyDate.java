package com.qmx.work7;

public class MyDate {
    private int year;
    private int month;
    private int day;

    public MyDate(int y, int m, int d){
        this.day = d;
        this.month = m;
        this.year = y;
    }

    public int getMonth() {
        return month;
    }
    public String toDateString(){
        return year + "年" + month + "月" + day + "日";
    }
}
