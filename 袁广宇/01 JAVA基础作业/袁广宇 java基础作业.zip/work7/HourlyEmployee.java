package com.qmx.work7;

public class HourlyEmployee extends Employee{
    private double wage;
    private double hour;

    public HourlyEmployee(String name, String number, MyDate birthday, double h, double w) {
        super(name, number, birthday);
        this.hour = h;
        this.wage = w;
    }

    @Override
    public double earnings() {
        return wage * hour * 27;
    }
    public String toString(){
        super.toString();
        System.out.println("工种为：HourlyEmployee");
        return "HourlyEmployee:";
    }
}
