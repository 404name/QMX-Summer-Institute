package com.qmx.test;

import com.qmx.work1.Common_Numbers;
import com.qmx.work1.Convention_Numbers;
import com.qmx.work2.Ball;
import com.qmx.work2.Circle;
import com.qmx.work2.Cone;
import com.qmx.work2.Cylinder;

public class test {
    public static void main(String[] args){
        //work 1
        /*
        Convention_Numbers test1_1 = new Convention_Numbers();
        System.out.println(test1_1.f(6, 12));
        Common_Numbers test1_2 = new Common_Numbers();
        System.out.println(test1_2.f(6,12));
        System.out.println("hello IDEA!");
        */
        // work 1

        //work 2
            //Circle
        /*
        Circle test2_1 = new Circle(2);
        System.out.println(test2_1.getArea());
        test2_1.setR(4);
        System.out.println(test2_1.getArea());
        System.out.println("hello IDEA!");
            //Circle
         */
        /*
            //Ball
        Ball test2_2 = new Ball(2);
        System.out.println(test2_2.getVolume());
        test2_2.setR(4);
        System.out.println(test2_2.getVolume());
        System.out.println("hello IDEA!");
            //Ball
        */
        /*
            //Cone
        Cone test2_3 = new Cone(2, 2);
        System.out.println(test2_3.getHigh());
        System.out.println(test2_3.getVolume());
        test2_3.setR(4);
        System.out.println(test2_3.getVolume());
            //Cone
        */
            //Cylinder
        Cylinder test2_4 = new Cylinder(2, 2);
        System.out.println(test2_4.getHigh());
        System.out.println(test2_4.getVolume());
        test2_4.setR(4);
        System.out.println(test2_4.getVolume());
            //Cylinder
        //work 2
    }
}
